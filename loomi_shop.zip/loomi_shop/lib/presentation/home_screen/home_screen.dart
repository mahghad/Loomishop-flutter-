import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/category_card_widget.dart';
import './widgets/hero_banner_widget.dart';
import './widgets/recommended_card_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();
  bool _isRefreshing = false;
  int _currentBannerIndex = 0;
  late PageController _bannerPageController;

  // Mock data
  final List<Map<String, dynamic>> bannerData = [
    {
      "id": 1,
      "title": "Summer Sale",
      "subtitle": "Up to 70% Off",
      "image":
          "https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "backgroundColor": "gradient"
    },
    {
      "id": 2,
      "title": "New Arrivals",
      "subtitle": "Fresh Collection",
      "image":
          "https://images.pexels.com/photos/1884584/pexels-photo-1884584.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "backgroundColor": "gradient"
    },
    {
      "id": 3,
      "title": "Flash Deals",
      "subtitle": "Limited Time Only",
      "image":
          "https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "backgroundColor": "gradient"
    }
  ];

  final List<Map<String, dynamic>> categoryData = [
    {
      "id": 1,
      "name": "Electronics",
      "icon": "devices",
      "image":
          "https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "itemCount": 150
    },
    {
      "id": 2,
      "name": "Fashion",
      "icon": "checkroom",
      "image":
          "https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "itemCount": 320
    },
    {
      "id": 3,
      "name": "Home & Garden",
      "icon": "home",
      "image":
          "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "itemCount": 89
    },
    {
      "id": 4,
      "name": "Sports",
      "icon": "sports_soccer",
      "image":
          "https://images.pexels.com/photos/863988/pexels-photo-863988.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "itemCount": 76
    }
  ];

  final List<Map<String, dynamic>> recommendedProducts = [
    {
      "id": 1,
      "name": "Wireless Headphones",
      "price": "\$89.99",
      "originalPrice": "\$129.99",
      "image":
          "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.5,
      "discount": 30,
      "isWishlisted": false
    },
    {
      "id": 2,
      "name": "Smart Watch",
      "price": "\$199.99",
      "originalPrice": "\$249.99",
      "image":
          "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.8,
      "discount": 20,
      "isWishlisted": true
    },
    {
      "id": 3,
      "name": "Bluetooth Speaker",
      "price": "\$49.99",
      "originalPrice": "\$79.99",
      "image":
          "https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.2,
      "discount": 37,
      "isWishlisted": false
    },
    {
      "id": 4,
      "name": "Laptop Stand",
      "price": "\$29.99",
      "originalPrice": "\$39.99",
      "image":
          "https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.0,
      "discount": 25,
      "isWishlisted": false
    },
    {
      "id": 5,
      "name": "Phone Case",
      "price": "\$19.99",
      "originalPrice": "\$29.99",
      "image":
          "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.3,
      "discount": 33,
      "isWishlisted": true
    },
    {
      "id": 6,
      "name": "USB Cable",
      "price": "\$12.99",
      "originalPrice": "\$19.99",
      "image":
          "https://images.pexels.com/photos/163100/circuit-circuit-board-resistor-computer-163100.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "rating": 4.1,
      "discount": 35,
      "isWishlisted": false
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _bannerPageController = PageController();
    _startBannerAutoScroll();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    _bannerPageController.dispose();
    super.dispose();
  }

  void _startBannerAutoScroll() {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted && _bannerPageController.hasClients) {
        final nextIndex = (_currentBannerIndex + 1) % bannerData.length;
        _bannerPageController.animateToPage(
          nextIndex,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
        _startBannerAutoScroll();
      }
    });
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      setState(() {
        _isRefreshing = false;
      });
    }
  }

  void _onProductTap(Map<String, dynamic> product) {
    Navigator.pushNamed(context, '/product-detail');
  }

  void _onCategoryTap(Map<String, dynamic> category) {
    Navigator.pushNamed(context, '/product-catalog');
  }

  void _toggleWishlist(int productId) {
    setState(() {
      final productIndex =
          recommendedProducts.indexWhere((p) => (p["id"] as int) == productId);
      if (productIndex != -1) {
        recommendedProducts[productIndex]["isWishlisted"] =
            !(recommendedProducts[productIndex]["isWishlisted"] as bool);
      }
    });
  }

  void _addToCart(Map<String, dynamic> product) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product["name"]} added to cart'),
        backgroundColor: AppTheme.successGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Column(
        children: [
          // Sticky Header
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  children: [
                    // App Bar
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: 6.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: AppTheme.neutralLight,
                                width: 1,
                              ),
                            ),
                            child: TextField(
                              decoration: InputDecoration(
                                hintText: 'Search products...',
                                hintStyle: AppTheme
                                    .lightTheme.textTheme.bodyMedium
                                    ?.copyWith(
                                  color: AppTheme.textMediumEmphasisLight,
                                ),
                                prefixIcon: CustomIconWidget(
                                  iconName: 'search',
                                  color: AppTheme.neutralMedium,
                                  size: 20,
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 4.w, vertical: 1.h),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: AppTheme.primaryBlue,
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 3.w),
                        GestureDetector(
                          onTap: () => Navigator.pushNamed(
                              context, AppRoutes.aiRecommendations),
                          child: Container(
                            height: 6.h,
                            width: 6.h,
                            decoration: AppTheme.createGradientDecoration(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'auto_awesome',
                                color: AppTheme.pureWhite,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Container(
                          height: 6.h,
                          width: 6.h,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.neutralLight,
                              width: 1,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Center(
                                child: CustomIconWidget(
                                  iconName: 'notifications_outlined',
                                  color: AppTheme.neutralDark,
                                  size: 24,
                                ),
                              ),
                              Positioned(
                                top: 1.h,
                                right: 1.5.w,
                                child: Container(
                                  width: 2.w,
                                  height: 2.w,
                                  decoration: const BoxDecoration(
                                    color: AppTheme.primaryPurple,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2.h),
                    // Tab Bar
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.neutralLight.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        isScrollable: true,
                        tabAlignment: TabAlignment.start,
                        indicator: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [
                              AppTheme.primaryBlue,
                              AppTheme.primaryPurple
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        labelColor: AppTheme.pureWhite,
                        unselectedLabelColor: AppTheme.neutralMedium,
                        labelStyle:
                            AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        unselectedLabelStyle:
                            AppTheme.lightTheme.textTheme.labelMedium,
                        tabs: const [
                          Tab(text: 'Home'),
                          Tab(text: 'Categories'),
                          Tab(text: 'Deals'),
                          Tab(text: 'Brands'),
                          Tab(text: 'New'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Main Content
          Expanded(
            child: RefreshIndicator(
              onRefresh: _handleRefresh,
              color: AppTheme.primaryBlue,
              backgroundColor: AppTheme.pureWhite,
              child: SingleChildScrollView(
                controller: _scrollController,
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hero Banner
                    SizedBox(
                      height: 25.h,
                      child: PageView.builder(
                        controller: _bannerPageController,
                        onPageChanged: (index) {
                          setState(() {
                            _currentBannerIndex = index;
                          });
                        },
                        itemCount: bannerData.length,
                        itemBuilder: (context, index) {
                          final banner = bannerData[index];
                          return HeroBannerWidget(
                            banner: banner,
                            onTap: () => _onCategoryTap(banner),
                          );
                        },
                      ),
                    ),
                    // Page Indicators
                    SizedBox(height: 2.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        bannerData.length,
                        (index) => Container(
                          margin: EdgeInsets.symmetric(horizontal: 1.w),
                          width: _currentBannerIndex == index ? 4.w : 2.w,
                          height: 1.h,
                          decoration: BoxDecoration(
                            gradient: _currentBannerIndex == index
                                ? const LinearGradient(
                                    colors: [
                                      AppTheme.primaryBlue,
                                      AppTheme.primaryPurple
                                    ],
                                  )
                                : null,
                            color: _currentBannerIndex == index
                                ? null
                                : AppTheme.neutralLight,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 3.h),
                    // Categories Section
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Shop by Category',
                            style: AppTheme.lightTheme.textTheme.titleLarge
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pushNamed(
                                context, '/product-catalog'),
                            child: Text(
                              'View All',
                              style: AppTheme.lightTheme.textTheme.labelLarge
                                  ?.copyWith(
                                color: AppTheme.primaryBlue,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 2.h),
                    SizedBox(
                      height: 15.h,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: EdgeInsets.symmetric(horizontal: 4.w),
                        itemCount: categoryData.length,
                        itemBuilder: (context, index) {
                          final category = categoryData[index];
                          return CategoryCardWidget(
                            category: category,
                            onTap: () => _onCategoryTap(category),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: 4.h),
                    // Recommended Products Section
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Recommended for You',
                            style: AppTheme.lightTheme.textTheme.titleLarge
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pushNamed(
                                context, '/product-catalog'),
                            child: Text(
                              'See All',
                              style: AppTheme.lightTheme.textTheme.labelLarge
                                  ?.copyWith(
                                color: AppTheme.primaryBlue,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 2.h),
                    // Products Grid
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.75,
                          crossAxisSpacing: 3.w,
                          mainAxisSpacing: 2.h,
                        ),
                        itemCount: recommendedProducts.length,
                        itemBuilder: (context, index) {
                          final product = recommendedProducts[index];
                          return RecommendedCardWidget(
                            product: product,
                            onTap: () => _onProductTap(product),
                            onWishlistTap: () =>
                                _toggleWishlist(product["id"] as int),
                            onAddToCart: () => _addToCart(product),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: 10.h),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      // Bottom Navigation Bar
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: AppTheme.shadowLight,
              blurRadius: 8,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: AppTheme.pureWhite,
          selectedItemColor: AppTheme.primaryBlue,
          unselectedItemColor: AppTheme.neutralMedium,
          currentIndex: 0,
          onTap: (index) {
            switch (index) {
              case 0:
                // Already on home
                break;
              case 1:
                Navigator.pushNamed(context, '/product-catalog');
                break;
              case 2:
                Navigator.pushNamed(context, '/product-catalog');
                break;
              case 3:
                Navigator.pushNamed(context, '/product-catalog');
                break;
              case 4:
                Navigator.pushNamed(context, '/user-profile');
                break;
            }
          },
          items: [
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'home',
                color: AppTheme.primaryBlue,
                size: 24,
              ),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'category',
                color: AppTheme.neutralMedium,
                size: 24,
              ),
              label: 'Categories',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'local_offer',
                color: AppTheme.neutralMedium,
                size: 24,
              ),
              label: 'Deals',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'shopping_cart',
                color: AppTheme.neutralMedium,
                size: 24,
              ),
              label: 'Cart',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'person',
                color: AppTheme.neutralMedium,
                size: 24,
              ),
              label: 'Profile',
            ),
          ],
        ),
      ),
      // Floating Action Button
      floatingActionButton: Container(
        decoration: AppTheme.createGradientDecoration(
          borderRadius: BorderRadius.circular(16),
        ),
        child: FloatingActionButton(
          onPressed: () =>
              Navigator.pushNamed(context, AppRoutes.aiRecommendations),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: CustomIconWidget(
            iconName: 'auto_awesome',
            color: AppTheme.pureWhite,
            size: 28,
          ),
        ),
      ),
    );
  }
}
