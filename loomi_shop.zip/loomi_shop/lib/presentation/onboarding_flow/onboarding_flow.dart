import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import './widgets/onboarding_page_widget.dart';
import './widgets/page_indicator_widget.dart';

class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({super.key});

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  int _currentPage = 0;

  final List<Map<String, dynamic>> _onboardingData = [
    {
      "id": 1,
      "title": "Discover Amazing Products",
      "description":
          "Explore thousands of products with our smart discovery engine that learns your preferences and suggests items you'll love.",
      "imageUrl":
          "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "gradientColors": [AppTheme.primaryCyan, AppTheme.deepBlue],
    },
    {
      "id": 2,
      "title": "Personalized Recommendations",
      "description":
          "Get tailored product suggestions based on your shopping history, preferences, and trending items in your area.",
      "imageUrl":
          "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "gradientColors": [AppTheme.primaryPink, AppTheme.softMagenta],
    },
    {
      "id": 3,
      "title": "Secure Checkout",
      "description":
          "Shop with confidence using our encrypted payment system with multiple secure payment options and buyer protection.",
      "imageUrl":
          "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "gradientColors": [AppTheme.successGreen, AppTheme.primaryCyan],
    },
    {
      "id": 4,
      "title": "Fast Delivery Tracking",
      "description":
          "Track your orders in real-time from warehouse to your doorstep with live updates and delivery notifications.",
      "imageUrl":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "gradientColors": [AppTheme.primaryCyan, AppTheme.primaryPink],
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
    _animationController.reset();
    _animationController.forward();
  }

  void _nextPage() {
    if (_currentPage < _onboardingData.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _navigateToHome();
    }
  }

  void _skipOnboarding() {
    _navigateToHome();
  }

  void _navigateToHome() {
    Navigator.pushReplacementNamed(context, '/home-screen');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            // Background gradient
            Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: (_onboardingData[_currentPage]["gradientColors"]
                          as List<Color>)
                      .map((color) => color.withValues(alpha: 0.1))
                      .toList(),
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),

            // Skip button
            Positioned(
              top: 2.h,
              right: 4.w,
              child: TextButton(
                onPressed: _skipOnboarding,
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.lightTheme.colorScheme.onSurface,
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                ),
                child: Text(
                  'Skip',
                  style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),

            // Main content
            Column(
              children: [
                SizedBox(height: 8.h),

                // Page view
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: _onPageChanged,
                    itemCount: _onboardingData.length,
                    itemBuilder: (context, index) {
                      return FadeTransition(
                        opacity: _fadeAnimation,
                        child: OnboardingPageWidget(
                          data: _onboardingData[index],
                        ),
                      );
                    },
                  ),
                ),

                SizedBox(height: 4.h),

                // Page indicator
                PageIndicatorWidget(
                  currentPage: _currentPage,
                  totalPages: _onboardingData.length,
                ),

                SizedBox(height: 6.h),

                // Navigation buttons
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 6.w),
                  child: Row(
                    children: [
                      // Previous button (only show after first page)
                      _currentPage > 0
                          ? Expanded(
                              child: OutlinedButton(
                                onPressed: () {
                                  _pageController.previousPage(
                                    duration: const Duration(milliseconds: 300),
                                    curve: Curves.easeInOut,
                                  );
                                },
                                style: OutlinedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(vertical: 2.h),
                                  side: BorderSide(
                                    color:
                                        AppTheme.lightTheme.colorScheme.primary,
                                    width: 1.5,
                                  ),
                                ),
                                child: Text(
                                  'Previous',
                                  style: AppTheme
                                      .lightTheme.textTheme.titleMedium
                                      ?.copyWith(
                                    color:
                                        AppTheme.lightTheme.colorScheme.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),

                      _currentPage > 0
                          ? SizedBox(width: 4.w)
                          : const SizedBox.shrink(),

                      // Next/Get Started button
                      Expanded(
                        flex: _currentPage > 0 ? 1 : 2,
                        child: Container(
                          decoration: AppTheme.createGradientDecoration(
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          child: ElevatedButton(
                            onPressed: _nextPage,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              padding: EdgeInsets.symmetric(vertical: 2.h),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                            ),
                            child: Text(
                              _currentPage == _onboardingData.length - 1
                                  ? 'Get Started'
                                  : 'Next',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                color: AppTheme.pureWhite,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 4.h),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
