import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class OnboardingPageWidget extends StatelessWidget {
  final Map<String, dynamic> data;

  const OnboardingPageWidget({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Illustration container with 3D effect
          Container(
            width: 70.w,
            height: 35.h,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20.0),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 20.0,
                  offset: const Offset(0, 8),
                  spreadRadius: 2.0,
                ),
                BoxShadow(
                  color: (data["gradientColors"] as List<Color>)[0]
                      .withValues(alpha: 0.2),
                  blurRadius: 30.0,
                  offset: const Offset(0, 12),
                  spreadRadius: -5.0,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20.0),
              child: Stack(
                children: [
                  // Background image
                  CustomImageWidget(
                    imageUrl: data["imageUrl"] as String,
                    width: double.infinity,
                    height: double.infinity,
                    fit: BoxFit.cover,
                  ),

                  // Gradient overlay for 3D effect
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          (data["gradientColors"] as List<Color>)[0]
                              .withValues(alpha: 0.3),
                          (data["gradientColors"] as List<Color>)[1]
                              .withValues(alpha: 0.1),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),

                  // Shine effect
                  Positioned(
                    top: 2.h,
                    right: 4.w,
                    child: Container(
                      width: 15.w,
                      height: 8.h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            AppTheme.pureWhite.withValues(alpha: 0.4),
                            AppTheme.pureWhite.withValues(alpha: 0.0),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 6.h),

          // Title with gradient text effect
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: data["gradientColors"] as List<Color>,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: Text(
              data["title"] as String,
              textAlign: TextAlign.center,
              style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
            ),
          ),

          SizedBox(height: 3.h),

          // Description
          Container(
            constraints: BoxConstraints(maxWidth: 85.w),
            child: Text(
              data["description"] as String,
              textAlign: TextAlign.center,
              style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.8),
                height: 1.5,
                fontSize: 16.sp,
              ),
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
            ),
          ),

          SizedBox(height: 4.h),

          // Feature highlights
          _buildFeatureHighlights(),
        ],
      ),
    );
  }

  Widget _buildFeatureHighlights() {
    final List<String> features = _getFeaturesByPage();

    return Column(
      children: features.map((feature) {
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 0.5.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 2.w,
                height: 2.w,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: data["gradientColors"] as List<Color>,
                  ),
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 3.w),
              Flexible(
                child: Text(
                  feature,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.7),
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  List<String> _getFeaturesByPage() {
    switch (data["id"] as int) {
      case 1:
        return [
          "Smart search filters",
          "Category browsing",
          "Wishlist management"
        ];
      case 2:
        return [
          "AI-powered suggestions",
          "Trending products",
          "Personal preferences"
        ];
      case 3:
        return [
          "Multiple payment options",
          "Encrypted transactions",
          "Buyer protection"
        ];
      case 4:
        return [
          "Real-time tracking",
          "Delivery notifications",
          "Order history"
        ];
      default:
        return [];
    }
  }
}
