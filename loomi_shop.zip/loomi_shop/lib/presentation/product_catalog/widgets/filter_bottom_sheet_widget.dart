import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FilterBottomSheetWidget extends StatefulWidget {
  final List<String> activeFilters;
  final Function(List<String>) onFiltersChanged;

  const FilterBottomSheetWidget({
    super.key,
    required this.activeFilters,
    required this.onFiltersChanged,
  });

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late List<String> _tempFilters;

  final Map<String, List<String>> _filterOptions = {
    'Category': [
      'Electronics',
      'Fashion',
      'Home & Kitchen',
      'Sports',
      'Books',
      'Beauty'
    ],
    'Price Range': [
      'Under \$25',
      'Under \$50',
      'Under \$100',
      'Under \$200',
      'Over \$200'
    ],
    'Brand': [
      'TechSound',
      'FitTech',
      'BrewMaster',
      'EcoWear',
      'SoundWave',
      'ZenFit'
    ],
    'Size': ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    'Color': ['Black', 'White', 'Blue', 'Red', 'Green', 'Pink'],
  };

  final Map<String, bool> _expandedSections = {
    'Category': true,
    'Price Range': false,
    'Brand': false,
    'Size': false,
    'Color': false,
  };

  @override
  void initState() {
    super.initState();
    _tempFilters = List.from(widget.activeFilters);
  }

  void _toggleFilter(String filter) {
    setState(() {
      if (_tempFilters.contains(filter)) {
        _tempFilters.remove(filter);
      } else {
        _tempFilters.add(filter);
      }
    });
  }

  void _clearAllFilters() {
    setState(() {
      _tempFilters.clear();
    });
  }

  void _applyFilters() {
    widget.onFiltersChanged(_tempFilters);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.pureWhite,
            AppTheme.primaryCyan.withValues(alpha: 0.05),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                children: _filterOptions.entries.map((entry) {
                  return _buildFilterSection(entry.key, entry.value);
                }).toList(),
              ),
            ),
          ),
          _buildBottomActions(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: AppTheme.neutralLight,
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 40.w,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.neutralMedium,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Filters',
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton(
                onPressed: _clearAllFilters,
                child: Text(
                  'Clear All',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection(String title, List<String> options) {
    final bool isExpanded = _expandedSections[title] ?? false;

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.pureWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.neutralLight,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _expandedSections[title] = !isExpanded;
              });
            },
            child: Container(
              padding: EdgeInsets.all(4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  CustomIconWidget(
                    iconName: isExpanded ? 'expand_less' : 'expand_more',
                    color: AppTheme.neutralMedium,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded)
            Container(
              padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
              child: Wrap(
                spacing: 2.w,
                runSpacing: 2.w,
                children: options.map((option) {
                  final bool isSelected = _tempFilters.contains(option);
                  return GestureDetector(
                    onTap: () => _toggleFilter(option),
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.w),
                      decoration: BoxDecoration(
                        gradient: isSelected
                            ? LinearGradient(
                                colors: [
                                  AppTheme.primaryCyan,
                                  AppTheme.primaryPink
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              )
                            : null,
                        color: isSelected ? null : AppTheme.neutralLight,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected
                              ? Colors.transparent
                              : AppTheme.neutralMedium.withValues(alpha: 0.3),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        option,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isSelected
                              ? AppTheme.pureWhite
                              : AppTheme.neutralDark,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBottomActions() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.pureWhite,
        border: Border(
          top: BorderSide(
            color: AppTheme.neutralLight,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 3.w),
                side: BorderSide(color: AppTheme.neutralMedium),
              ),
              child: Text('Cancel'),
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: ElevatedButton(
              onPressed: _applyFilters,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 3.w),
                backgroundColor: AppTheme.primaryCyan,
              ),
              child: Text(
                'Apply (${_tempFilters.length})',
                style: const TextStyle(color: AppTheme.pureWhite),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
