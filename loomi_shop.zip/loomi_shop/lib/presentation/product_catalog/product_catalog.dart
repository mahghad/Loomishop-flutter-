import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/filter_chip_widget.dart';
import './widgets/product_card_widget.dart';
import './widgets/sort_bottom_sheet_widget.dart';

class ProductCatalog extends StatefulWidget {
  const ProductCatalog({super.key});

  @override
  State<ProductCatalog> createState() => _ProductCatalogState();
}

class _ProductCatalogState extends State<ProductCatalog> {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();

  bool _isLoading = false;
  bool _isLoadingMore = false;
  String _selectedSort = 'Relevance';
  List<String> _activeFilters = ['Electronics', 'Under \$100'];

  // Mock product data
  final List<Map<String, dynamic>> _allProducts = [
    {
      "id": 1,
      "name": "Wireless Bluetooth Headphones",
      "price": "\$89.99",
      "originalPrice": "\$129.99",
      "rating": 4.5,
      "reviewCount": 234,
      "image":
          "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop",
      "category": "Electronics",
      "brand": "TechSound",
      "isOnSale": true,
      "discount": "31% OFF"
    },
    {
      "id": 2,
      "name": "Smart Fitness Watch",
      "price": "\$199.99",
      "originalPrice": null,
      "rating": 4.8,
      "reviewCount": 567,
      "image":
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
      "category": "Electronics",
      "brand": "FitTech",
      "isOnSale": false,
      "discount": null
    },
    {
      "id": 3,
      "name": "Premium Coffee Maker",
      "price": "\$149.99",
      "originalPrice": "\$199.99",
      "rating": 4.3,
      "reviewCount": 123,
      "image":
          "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=400&fit=crop",
      "category": "Home & Kitchen",
      "brand": "BrewMaster",
      "isOnSale": true,
      "discount": "25% OFF"
    },
    {
      "id": 4,
      "name": "Organic Cotton T-Shirt",
      "price": "\$29.99",
      "originalPrice": null,
      "rating": 4.6,
      "reviewCount": 89,
      "image":
          "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
      "category": "Fashion",
      "brand": "EcoWear",
      "isOnSale": false,
      "discount": null
    },
    {
      "id": 5,
      "name": "Portable Bluetooth Speaker",
      "price": "\$59.99",
      "originalPrice": "\$79.99",
      "rating": 4.4,
      "reviewCount": 345,
      "image":
          "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop",
      "category": "Electronics",
      "brand": "SoundWave",
      "isOnSale": true,
      "discount": "25% OFF"
    },
    {
      "id": 6,
      "name": "Yoga Mat Premium",
      "price": "\$39.99",
      "originalPrice": null,
      "rating": 4.7,
      "reviewCount": 156,
      "image":
          "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=400&fit=crop",
      "category": "Sports",
      "brand": "ZenFit",
      "isOnSale": false,
      "discount": null
    },
    {
      "id": 7,
      "name": "Wireless Phone Charger",
      "price": "\$24.99",
      "originalPrice": "\$34.99",
      "rating": 4.2,
      "reviewCount": 78,
      "image":
          "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400&h=400&fit=crop",
      "category": "Electronics",
      "brand": "ChargeTech",
      "isOnSale": true,
      "discount": "29% OFF"
    },
    {
      "id": 8,
      "name": "Stainless Steel Water Bottle",
      "price": "\$19.99",
      "originalPrice": null,
      "rating": 4.5,
      "reviewCount": 234,
      "image":
          "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop",
      "category": "Sports",
      "brand": "HydroLife",
      "isOnSale": false,
      "discount": null
    }
  ];

  List<Map<String, dynamic>> _displayedProducts = [];
  int _currentPage = 0;
  final int _itemsPerPage = 6;

  @override
  void initState() {
    super.initState();
    _loadInitialProducts();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _loadInitialProducts() {
    setState(() {
      _isLoading = true;
    });

    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _displayedProducts = _allProducts.take(_itemsPerPage).toList();
        _currentPage = 1;
        _isLoading = false;
      });
    });
  }

  void _loadMoreProducts() {
    if (_isLoadingMore || _displayedProducts.length >= _allProducts.length) {
      return;
    }

    setState(() {
      _isLoadingMore = true;
    });

    Future.delayed(const Duration(milliseconds: 500), () {
      final startIndex = _currentPage * _itemsPerPage;
      final endIndex =
          (startIndex + _itemsPerPage).clamp(0, _allProducts.length);

      setState(() {
        _displayedProducts.addAll(_allProducts.sublist(startIndex, endIndex));
        _currentPage++;
        _isLoadingMore = false;
      });
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _loadMoreProducts();
    }
  }

  Future<void> _onRefresh() async {
    await Future.delayed(const Duration(milliseconds: 1000));
    setState(() {
      _displayedProducts = _allProducts.take(_itemsPerPage).toList();
      _currentPage = 1;
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        activeFilters: _activeFilters,
        onFiltersChanged: (filters) {
          setState(() {
            _activeFilters = filters;
          });
        },
      ),
    );
  }

  void _showSortBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => SortBottomSheetWidget(
        selectedSort: _selectedSort,
        onSortChanged: (sort) {
          setState(() {
            _selectedSort = sort;
          });
        },
      ),
    );
  }

  void _removeFilter(String filter) {
    setState(() {
      _activeFilters.remove(filter);
    });
  }

  void _onProductTap(Map<String, dynamic> product) {
    Navigator.pushNamed(context, '/product-detail');
  }

  void _onProductLongPress(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildProductContextMenu(product),
    );
  }

  Widget _buildProductContextMenu(Map<String, dynamic> product) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryCyan.withValues(alpha: 0.1),
            AppTheme.primaryPink.withValues(alpha: 0.1),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40.w,
            height: 4,
            margin: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.neutralMedium,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          _buildContextMenuItem('Add to Wishlist', 'favorite_border'),
          _buildContextMenuItem('Share', 'share'),
          _buildContextMenuItem('Compare', 'compare_arrows'),
          _buildContextMenuItem('Similar Items', 'search'),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildContextMenuItem(String title, String iconName) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: AppTheme.primaryCyan,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
      onTap: () {
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildStickyHeader(),
            _buildActiveFilters(),
            Expanded(
              child: _isLoading ? _buildLoadingGrid() : _buildProductGrid(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStickyHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: AppTheme.neutralDark,
                  size: 24,
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.primaryCyan.withValues(alpha: 0.1),
                        AppTheme.primaryPink.withValues(alpha: 0.1),
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                      width: 1,
                    ),
                  ),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Search products...',
                      prefixIcon: CustomIconWidget(
                        iconName: 'search',
                        color: AppTheme.neutralMedium,
                        size: 20,
                      ),
                      suffixIcon: CustomIconWidget(
                        iconName: 'mic',
                        color: AppTheme.primaryCyan,
                        size: 20,
                      ),
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Product Catalog',
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: _showFilterBottomSheet,
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryCyan, AppTheme.primaryPink],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: CustomIconWidget(
                        iconName: 'filter_list',
                        color: AppTheme.pureWhite,
                        size: 20,
                      ),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  GestureDetector(
                    onTap: _showSortBottomSheet,
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryPink, AppTheme.primaryCyan],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: CustomIconWidget(
                        iconName: 'sort',
                        color: AppTheme.pureWhite,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActiveFilters() {
    if (_activeFilters.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 6.h,
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _activeFilters.length,
        itemBuilder: (context, index) {
          return FilterChipWidget(
            label: _activeFilters[index],
            isActive: true,
            onTap: () => _removeFilter(_activeFilters[index]),
            showClose: true,
          );
        },
      ),
    );
  }

  Widget _buildProductGrid() {
    return RefreshIndicator(
      onRefresh: _onRefresh,
      color: AppTheme.primaryCyan,
      child: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverPadding(
            padding: EdgeInsets.all(4.w),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount:
                    MediaQuery.of(context).orientation == Orientation.portrait
                        ? 2
                        : 3,
                crossAxisSpacing: 4.w,
                mainAxisSpacing: 4.w,
                childAspectRatio: 0.75,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  if (index < _displayedProducts.length) {
                    return ProductCardWidget(
                      product: _displayedProducts[index],
                      onTap: () => _onProductTap(_displayedProducts[index]),
                      onLongPress: () =>
                          _onProductLongPress(_displayedProducts[index]),
                    );
                  }
                  return null;
                },
                childCount: _displayedProducts.length,
              ),
            ),
          ),
          if (_isLoadingMore)
            SliverToBoxAdapter(
              child: Container(
                padding: EdgeInsets.all(4.w),
                child: const Center(
                  child: CircularProgressIndicator(),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildLoadingGrid() {
    return Padding(
      padding: EdgeInsets.all(4.w),
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:
              MediaQuery.of(context).orientation == Orientation.portrait
                  ? 2
                  : 3,
          crossAxisSpacing: 4.w,
          mainAxisSpacing: 4.w,
          childAspectRatio: 0.75,
        ),
        itemCount: 6,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.neutralLight.withValues(alpha: 0.3),
                  AppTheme.neutralLight.withValues(alpha: 0.1),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: CircularProgressIndicator(),
            ),
          );
        },
      ),
    );
  }
}
