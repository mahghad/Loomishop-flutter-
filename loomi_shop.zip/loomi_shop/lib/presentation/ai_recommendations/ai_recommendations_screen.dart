import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class AIRecommendationsScreen extends StatefulWidget {
  const AIRecommendationsScreen({super.key});

  @override
  State<AIRecommendationsScreen> createState() =>
      _AIRecommendationsScreenState();
}

class _AIRecommendationsScreenState extends State<AIRecommendationsScreen> {
  final OpenAIClient _openAIClient = OpenAIClient(OpenAIService().dio);
  final TextEditingController _promptController = TextEditingController();
  String _recommendations = '';
  bool _isLoading = false;
  List<String> _generatedImages = [];

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  Future<void> _generateRecommendations() async {
    if (_promptController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter a product description')));
      return;
    }

    setState(() {
      _isLoading = true;
      _recommendations = '';
    });

    try {
      final messages = [
        Message(role: 'user', content: [
          {
            'type': 'text',
            'text':
                'As a smart shopping assistant for Loomi Shop, provide personalized product recommendations based on this query: "${_promptController.text}". Include product names, prices, and why each item would be a good fit. Format the response in a user-friendly way.'
          }
        ]),
      ];

      final response = await _openAIClient.createChatCompletion(
          messages: messages, model: 'gpt-4o', options: {'temperature': 0.7});

      setState(() {
        _recommendations = response.text;
      });
    } on OpenAIException catch (e) {
      setState(() {
        _recommendations = 'Error: ${e.message}';
      });
    } catch (e) {
      setState(() {
        _recommendations = 'Unexpected error occurred: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _generateProductImages() async {
    if (_promptController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter a product description')));
      return;
    }

    setState(() {
      _isLoading = true;
      _generatedImages.clear();
    });

    try {
      final imageUrls = await _openAIClient.generateImageUrls(
          prompt:
              'High-quality product photo of ${_promptController.text}, professional e-commerce style, white background',
          n: 2,
          size: '1024x1024',
          model: 'dall-e-3');

      setState(() {
        _generatedImages = imageUrls;
      });
    } on OpenAIException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Image generation error: ${e.message}')));
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Unexpected error: $e')));
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        appBar: AppBar(
            title: Text('AI Recommendations',
                style: AppTheme.lightTheme.textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700)),
            backgroundColor: AppTheme.pureWhite,
            elevation: 2,
            centerTitle: true,
            leading: IconButton(
                icon: CustomIconWidget(
                    iconName: 'arrow_back',
                    color: AppTheme.neutralDark,
                    size: 24),
                onPressed: () => Navigator.pop(context))),
        body: SingleChildScrollView(
            padding: EdgeInsets.all(4.w),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Header Section
              Container(
                  padding: EdgeInsets.all(4.w),
                  decoration: AppTheme.createGradientDecoration(),
                  child: Row(children: [
                    CustomIconWidget(
                        iconName: 'auto_awesome',
                        color: AppTheme.pureWhite,
                        size: 32),
                    SizedBox(width: 3.w),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text('AI-Powered Shopping',
                              style: AppTheme.lightTheme.textTheme.titleLarge
                                  ?.copyWith(
                                      color: AppTheme.pureWhite,
                                      fontWeight: FontWeight.w700)),
                          SizedBox(height: 1.h),
                          Text(
                              'Get personalized product recommendations and generate product visualizations',
                              style: AppTheme.lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                      color: AppTheme.pureWhite
                                          .withValues(alpha: 0.9))),
                        ])),
                  ])),
              SizedBox(height: 3.h),

              // Input Section
              Text('What are you looking for?',
                  style: AppTheme.lightTheme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w600)),
              SizedBox(height: 2.h),
              Container(
                  decoration: BoxDecoration(
                      color: AppTheme.pureWhite,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                            color: AppTheme.shadowLight,
                            blurRadius: 8,
                            offset: const Offset(0, 2)),
                      ]),
                  child: TextField(
                      controller: _promptController,
                      maxLines: 4,
                      decoration: InputDecoration(
                          hintText:
                              'E.g., "Wireless headphones for working out" or "Comfortable office chair under \$300"',
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.all(4.w)))),
              SizedBox(height: 3.h),

              // Action Buttons
              Row(children: [
                Expanded(
                    child: ElevatedButton.icon(
                        onPressed: _isLoading ? null : _generateRecommendations,
                        icon: CustomIconWidget(
                            iconName: 'psychology',
                            color: AppTheme.pureWhite,
                            size: 20),
                        label: const Text('Get Recommendations'),
                        style: ElevatedButton.styleFrom(
                            padding: EdgeInsets.symmetric(vertical: 2.h)))),
                SizedBox(width: 3.w),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: _isLoading ? null : _generateProductImages,
                        icon: CustomIconWidget(
                            iconName: 'image',
                            color: AppTheme.primaryBlue,
                            size: 20),
                        label: const Text('Generate Images'),
                        style: OutlinedButton.styleFrom(
                            padding: EdgeInsets.symmetric(vertical: 2.h)))),
              ]),
              SizedBox(height: 4.h),

              // Loading Indicator
              if (_isLoading)
                Center(
                    child: Column(children: [
                  CircularProgressIndicator(color: AppTheme.primaryBlue),
                  SizedBox(height: 2.h),
                  Text('AI is working on your request...',
                      style: AppTheme.lightTheme.textTheme.bodyMedium
                          ?.copyWith(color: AppTheme.neutralMedium)),
                ])),

              // Recommendations Section
              if (_recommendations.isNotEmpty && !_isLoading) ...[
                Text('AI Recommendations',
                    style: AppTheme.lightTheme.textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700)),
                SizedBox(height: 2.h),
                Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(4.w),
                    decoration: BoxDecoration(
                        color: AppTheme.pureWhite,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: AppTheme.primaryBlue.withValues(alpha: 0.3),
                            width: 1),
                        boxShadow: [
                          BoxShadow(
                              color: AppTheme.shadowLight,
                              blurRadius: 8,
                              offset: const Offset(0, 2)),
                        ]),
                    child: Text(_recommendations,
                        style: AppTheme.lightTheme.textTheme.bodyMedium)),
                SizedBox(height: 3.h),
              ],

              // Generated Images Section
              if (_generatedImages.isNotEmpty && !_isLoading) ...[
                Text('Generated Product Images',
                    style: AppTheme.lightTheme.textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700)),
                SizedBox(height: 2.h),
                GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 1,
                        crossAxisSpacing: 3.w,
                        mainAxisSpacing: 2.h),
                    itemCount: _generatedImages.length,
                    itemBuilder: (context, index) {
                      return Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                    color: AppTheme.shadowLight,
                                    blurRadius: 8,
                                    offset: const Offset(0, 2)),
                              ]),
                          child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: CustomImageWidget(
                                  imageUrl: _generatedImages[index],
                                  height: double.infinity,
                                  width: double.infinity,
                                  fit: BoxFit.cover)));
                    }),
                SizedBox(height: 3.h),
              ],

              // Features Section
              if (!_isLoading &&
                  _recommendations.isEmpty &&
                  _generatedImages.isEmpty) ...[
                Text('AI Features',
                    style: AppTheme.lightTheme.textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700)),
                SizedBox(height: 2.h),
                _buildFeatureCard(
                    icon: 'psychology',
                    title: 'Smart Recommendations',
                    description:
                        'Get personalized product suggestions based on your preferences and budget'),
                SizedBox(height: 2.h),
                _buildFeatureCard(
                    icon: 'image',
                    title: 'Product Visualization',
                    description:
                        'Generate realistic product images to visualize items before purchase'),
                SizedBox(height: 2.h),
                _buildFeatureCard(
                    icon: 'trending_up',
                    title: 'Price Insights',
                    description:
                        'AI-powered price analysis and best deal recommendations'),
              ],
            ])));
  }

  Widget _buildFeatureCard({
    required String icon,
    required String title,
    required String description,
  }) {
    return Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
            color: AppTheme.pureWhite,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2)),
            ]),
        child: Row(children: [
          Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [AppTheme.primaryBlue, AppTheme.primaryPurple],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight),
                  borderRadius: BorderRadius.circular(8)),
              child: CustomIconWidget(
                  iconName: icon, color: AppTheme.pureWhite, size: 24)),
          SizedBox(width: 4.w),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(title,
                    style: AppTheme.lightTheme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600)),
                SizedBox(height: 1.h),
                Text(description,
                    style: AppTheme.lightTheme.textTheme.bodyMedium
                        ?.copyWith(color: AppTheme.neutralMedium)),
              ])),
        ]));
  }
}