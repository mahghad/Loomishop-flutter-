import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/address_card_widget.dart';
import './widgets/order_history_card_widget.dart';
import './widgets/payment_method_card_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/profile_section_widget.dart';
import './widgets/settings_item_widget.dart';
import './widgets/wishlist_item_widget.dart';

class UserProfile extends StatefulWidget {
  const UserProfile({super.key});

  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final bool _isLoading = false;

  // Mock user data
  final Map<String, dynamic> userData = {
    "name": "Sarah Johnson",
    "email": "sarah.johnson@email.com",
    "membershipStatus": "Premium Member",
    "avatar":
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
    "joinDate": "March 2023"
  };

  final List<Map<String, dynamic>> orderHistory = [
    {
      "id": "ORD-2024-001",
      "date": "2024-01-15",
      "status": "Delivered",
      "total": "\$89.99",
      "items": 3,
      "image":
          "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=300&h=200&fit=crop"
    },
    {
      "id": "ORD-2024-002",
      "date": "2024-01-10",
      "status": "Processing",
      "total": "\$156.50",
      "items": 2,
      "image":
          "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=200&fit=crop"
    },
    {
      "id": "ORD-2024-003",
      "date": "2024-01-05",
      "status": "Shipped",
      "total": "\$234.75",
      "items": 5,
      "image":
          "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=300&h=200&fit=crop"
    }
  ];

  final List<Map<String, dynamic>> wishlistItems = [
    {
      "id": 1,
      "name": "Wireless Headphones",
      "price": "\$199.99",
      "image":
          "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
      "inStock": true
    },
    {
      "id": 2,
      "name": "Smart Watch",
      "price": "\$299.99",
      "image":
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop",
      "inStock": false
    },
    {
      "id": 3,
      "name": "Laptop Stand",
      "price": "\$79.99",
      "image":
          "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=300&h=300&fit=crop",
      "inStock": true
    }
  ];

  final List<Map<String, dynamic>> addresses = [
    {
      "id": 1,
      "type": "Home",
      "name": "Sarah Johnson",
      "address": "123 Main Street, Apt 4B",
      "city": "New York, NY 10001",
      "isDefault": true
    },
    {
      "id": 2,
      "type": "Work",
      "name": "Sarah Johnson",
      "address": "456 Business Ave, Suite 200",
      "city": "New York, NY 10005",
      "isDefault": false
    }
  ];

  final List<Map<String, dynamic>> paymentMethods = [
    {
      "id": 1,
      "type": "Visa",
      "lastFour": "4532",
      "expiry": "12/26",
      "isDefault": true
    },
    {
      "id": 2,
      "type": "Mastercard",
      "lastFour": "8901",
      "expiry": "08/25",
      "isDefault": false
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildProfileTab(),
                  _buildOrdersTab(),
                  _buildWishlistTab(),
                  _buildSettingsTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline,
                  width: 1,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 20,
              ),
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Text(
              'Profile',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          GestureDetector(
            onTap: _showLogoutDialog,
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                gradient: AppTheme.createGradientDecoration().gradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: CustomIconWidget(
                iconName: 'logout',
                color: AppTheme.pureWhite,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
          width: 1,
        ),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: AppTheme.createGradientDecoration().gradient,
          borderRadius: BorderRadius.circular(12),
        ),
        labelColor: AppTheme.pureWhite,
        unselectedLabelColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        labelStyle: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: AppTheme.lightTheme.textTheme.labelMedium,
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'Profile'),
          Tab(text: 'Orders'),
          Tab(text: 'Wishlist'),
          Tab(text: 'Settings'),
        ],
      ),
    );
  }

  Widget _buildProfileTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          ProfileHeaderWidget(userData: userData),
          SizedBox(height: 3.h),
          ProfileSectionWidget(
            title: 'Account Information',
            children: [
              _buildProfileItem('Personal Information', 'edit'),
              _buildProfileItem('Email Preferences', 'email'),
              _buildProfileItem('Password & Security', 'lock'),
            ],
          ),
          SizedBox(height: 2.h),
          ProfileSectionWidget(
            title: 'Address Book',
            children: (addresses as List).map((dynamic address) {
              final addressMap = address as Map<String, dynamic>;
              return AddressCardWidget(address: addressMap);
            }).toList(),
          ),
          SizedBox(height: 2.h),
          ProfileSectionWidget(
            title: 'Payment Methods',
            children: (paymentMethods as List).map((dynamic payment) {
              final paymentMap = payment as Map<String, dynamic>;
              return PaymentMethodCardWidget(paymentMethod: paymentMap);
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildOrdersTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order History',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          ...(orderHistory as List).map((dynamic order) {
            final orderMap = order as Map<String, dynamic>;
            return Padding(
              padding: EdgeInsets.only(bottom: 2.h),
              child: OrderHistoryCardWidget(order: orderMap),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildWishlistTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'My Wishlist',
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${wishlistItems.length} items',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 3.w,
              mainAxisSpacing: 2.h,
              childAspectRatio: 0.75,
            ),
            itemCount: wishlistItems.length,
            itemBuilder: (context, index) {
              final item = wishlistItems[index];
              return WishlistItemWidget(item: item);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          ProfileSectionWidget(
            title: 'Notifications',
            children: [
              SettingsItemWidget(
                title: 'Push Notifications',
                subtitle: 'Receive order updates and offers',
                isToggle: true,
                value: true,
                onToggle: (value) {},
              ),
              SettingsItemWidget(
                title: 'Email Notifications',
                subtitle: 'Marketing emails and newsletters',
                isToggle: true,
                value: false,
                onToggle: (value) {},
              ),
            ],
          ),
          SizedBox(height: 2.h),
          ProfileSectionWidget(
            title: 'Preferences',
            children: [
              SettingsItemWidget(
                title: 'Language',
                subtitle: 'English (US)',
                icon: 'language',
                onTap: () {},
              ),
              SettingsItemWidget(
                title: 'Currency',
                subtitle: 'USD (\$)',
                icon: 'attach_money',
                onTap: () {},
              ),
              SettingsItemWidget(
                title: 'Dark Mode',
                subtitle: 'Switch to dark theme',
                isToggle: true,
                value: false,
                onToggle: (value) {},
              ),
            ],
          ),
          SizedBox(height: 2.h),
          ProfileSectionWidget(
            title: 'Privacy & Security',
            children: [
              SettingsItemWidget(
                title: 'Privacy Policy',
                icon: 'privacy_tip',
                onTap: () {},
              ),
              SettingsItemWidget(
                title: 'Terms of Service',
                icon: 'description',
                onTap: () {},
              ),
              SettingsItemWidget(
                title: 'Data & Privacy',
                icon: 'security',
                onTap: () {},
              ),
            ],
          ),
          SizedBox(height: 4.h),
          _buildLogoutButton(),
        ],
      ),
    );
  }

  Widget _buildProfileItem(String title, String iconName) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              gradient:
                  AppTheme.createGradientDecoration(opacity: 0.1).gradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: AppTheme.primaryCyan,
              size: 20,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              title,
              style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          CustomIconWidget(
            iconName: 'chevron_right',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildLogoutButton() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 2.w),
      child: ElevatedButton(
        onPressed: _showLogoutDialog,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: AppTheme.warningOrange,
          elevation: 0,
          padding: EdgeInsets.symmetric(vertical: 2.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: AppTheme.warningOrange,
              width: 2,
            ),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'logout',
              color: AppTheme.warningOrange,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              'Logout',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.warningOrange,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppTheme.lightTheme.dialogBackgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Logout',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            'Are you sure you want to logout from your account?',
            style: AppTheme.lightTheme.textTheme.bodyLarge,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/splash-screen',
                  (route) => false,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.warningOrange,
                foregroundColor: AppTheme.pureWhite,
              ),
              child: Text(
                'Logout',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.pureWhite,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
