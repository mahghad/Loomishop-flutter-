import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/customer_reviews_widget.dart';
import './widgets/product_description_widget.dart';
import './widgets/product_image_carousel_widget.dart';
import './widgets/product_info_widget.dart';
import './widgets/product_options_widget.dart';
import './widgets/related_products_widget.dart';
import './widgets/sticky_bottom_bar_widget.dart';

class ProductDetail extends StatefulWidget {
  const ProductDetail({super.key});

  @override
  State<ProductDetail> createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
  final ScrollController _scrollController = ScrollController();
  bool _showStickyBar = false;
  int _selectedColorIndex = 0;
  int _selectedSizeIndex = 0;
  int _quantity = 1;
  bool _isWishlisted = false;
  bool _isAddingToCart = false;
  bool _isDescriptionExpanded = false;

  // Mock product data
  final Map<String, dynamic> productData = {
    "id": 1,
    "name": "Premium Wireless Headphones",
    "description":
        """Experience crystal-clear audio with our premium wireless headphones. Featuring advanced noise cancellation technology, 30-hour battery life, and premium comfort padding. Perfect for music lovers, professionals, and anyone who values superior sound quality.

These headphones are engineered with precision-tuned drivers that deliver rich bass, clear mids, and crisp highs. The adaptive noise cancellation automatically adjusts to your environment, ensuring an immersive listening experience whether you're at home, in the office, or traveling.

The ergonomic design features memory foam ear cushions and an adjustable headband for all-day comfort. Quick charge technology provides 3 hours of playback with just 15 minutes of charging.""",
    "currentPrice": 299.99,
    "originalPrice": 399.99,
    "rating": 4.5,
    "reviewCount": 1247,
    "inStock": true,
    "stockCount": 15,
    "images": [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&h=800&fit=crop",
      "https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&h=800&fit=crop",
    ],
    "colors": [
      {"name": "Midnight Black", "color": "#1a1a1a"},
      {"name": "Pearl White", "color": "#f8f8f8"},
      {"name": "Rose Gold", "color": "#e8b4a0"},
      {"name": "Space Gray", "color": "#8e8e93"},
    ],
    "sizes": ["Small", "Medium", "Large", "X-Large"],
    "features": [
      "Active Noise Cancellation",
      "30-hour battery life",
      "Quick charge technology",
      "Premium comfort padding",
      "Bluetooth 5.0 connectivity",
      "Built-in microphone",
    ],
  };

  final List<Map<String, dynamic>> relatedProducts = [
    {
      "id": 2,
      "name": "Wireless Earbuds Pro",
      "price": 199.99,
      "originalPrice": 249.99,
      "rating": 4.3,
      "image":
          "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop",
    },
    {
      "id": 3,
      "name": "Gaming Headset Elite",
      "price": 159.99,
      "originalPrice": 199.99,
      "rating": 4.6,
      "image":
          "https://images.unsplash.com/photo-1599669454699-248893623440?w=400&h=400&fit=crop",
    },
    {
      "id": 4,
      "name": "Studio Monitor Headphones",
      "price": 349.99,
      "originalPrice": 399.99,
      "rating": 4.8,
      "image":
          "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400&h=400&fit=crop",
    },
  ];

  final List<Map<String, dynamic>> customerReviews = [
    {
      "id": 1,
      "userName": "Sarah Johnson",
      "rating": 5,
      "date": "2024-01-15",
      "review":
          "Absolutely amazing sound quality! The noise cancellation works perfectly and the battery life is incredible. Worth every penny.",
      "helpful": 24,
      "verified": true,
    },
    {
      "id": 2,
      "userName": "Mike Chen",
      "rating": 4,
      "date": "2024-01-10",
      "review":
          "Great headphones overall. Comfortable for long listening sessions. Only minor complaint is they're a bit heavy.",
      "helpful": 18,
      "verified": true,
    },
    {
      "id": 3,
      "userName": "Emma Davis",
      "rating": 5,
      "date": "2024-01-08",
      "review":
          "Perfect for my daily commute. The quick charge feature is a lifesaver when I forget to charge them overnight.",
      "helpful": 31,
      "verified": true,
    },
  ];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final shouldShow = _scrollController.offset > 300;
    if (shouldShow != _showStickyBar) {
      setState(() {
        _showStickyBar = shouldShow;
      });
    }
  }

  void _onColorSelected(int index) {
    setState(() {
      _selectedColorIndex = index;
    });
    HapticFeedback.lightImpact();
  }

  void _onSizeSelected(int index) {
    setState(() {
      _selectedSizeIndex = index;
    });
    HapticFeedback.lightImpact();
  }

  void _onQuantityChanged(int newQuantity) {
    if (newQuantity >= 1 && newQuantity <= (productData["stockCount"] as int)) {
      setState(() {
        _quantity = newQuantity;
      });
      HapticFeedback.lightImpact();
    }
  }

  void _toggleWishlist() {
    setState(() {
      _isWishlisted = !_isWishlisted;
    });
    HapticFeedback.lightImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            Text(_isWishlisted ? 'Added to wishlist' : 'Removed from wishlist'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _addToCart() async {
    setState(() {
      _isAddingToCart = true;
    });

    HapticFeedback.mediumImpact();

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isAddingToCart = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Added $_quantity item(s) to cart'),
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'View Cart',
          onPressed: () {
            // Navigate to cart
          },
        ),
      ),
    );
  }

  void _shareProduct() {
    HapticFeedback.lightImpact();
    // Implement share functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Share functionality would be implemented here'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _toggleDescription() {
    setState(() {
      _isDescriptionExpanded = !_isDescriptionExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          CustomScrollView(
            controller: _scrollController,
            slivers: [
              // Custom App Bar
              SliverAppBar(
                expandedHeight: 0,
                floating: true,
                pinned: true,
                backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor
                    .withValues(alpha: 0.95),
                elevation: 0,
                leading: Container(
                  margin: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    gradient: AppTheme.createGradientDecoration().gradient,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        child: CustomIconWidget(
                          iconName: 'arrow_back',
                          color: AppTheme.pureWhite,
                          size: 5.w,
                        ),
                      ),
                    ),
                  ),
                ),
                actions: [
                  Container(
                    margin: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.scaffoldBackgroundColor,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.shadowLight,
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: _shareProduct,
                        child: Container(
                          padding: EdgeInsets.all(2.w),
                          child: CustomIconWidget(
                            iconName: 'share',
                            color: AppTheme.neutralDark,
                            size: 5.w,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // Product Content
              SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Product Image Carousel
                    ProductImageCarouselWidget(
                      images: (productData["images"] as List).cast<String>(),
                    ),

                    SizedBox(height: 3.h),

                    // Product Info
                    ProductInfoWidget(
                      name: productData["name"] as String,
                      currentPrice: productData["currentPrice"] as double,
                      originalPrice: productData["originalPrice"] as double,
                      rating: productData["rating"] as double,
                      reviewCount: productData["reviewCount"] as int,
                      inStock: productData["inStock"] as bool,
                      stockCount: productData["stockCount"] as int,
                    ),

                    SizedBox(height: 3.h),

                    // Product Options
                    ProductOptionsWidget(
                      colors: (productData["colors"] as List)
                          .cast<Map<String, dynamic>>(),
                      sizes: (productData["sizes"] as List).cast<String>(),
                      selectedColorIndex: _selectedColorIndex,
                      selectedSizeIndex: _selectedSizeIndex,
                      quantity: _quantity,
                      maxQuantity: productData["stockCount"] as int,
                      onColorSelected: _onColorSelected,
                      onSizeSelected: _onSizeSelected,
                      onQuantityChanged: _onQuantityChanged,
                    ),

                    SizedBox(height: 3.h),

                    // Action Buttons
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              height: 7.h,
                              decoration: AppTheme.createGradientDecoration(),
                              child: ElevatedButton(
                                onPressed: _isAddingToCart ? null : _addToCart,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                child: _isAddingToCart
                                    ? SizedBox(
                                        width: 5.w,
                                        height: 5.w,
                                        child: const CircularProgressIndicator(
                                          color: AppTheme.pureWhite,
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : Text(
                                        'Add to Cart',
                                        style: AppTheme
                                            .lightTheme.textTheme.titleMedium
                                            ?.copyWith(
                                          color: AppTheme.pureWhite,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Container(
                            height: 7.h,
                            width: 7.h,
                            decoration: BoxDecoration(
                              border: Border.all(
                                width: 2,
                                color: _isWishlisted
                                    ? AppTheme.primaryPink
                                    : AppTheme.primaryCyan,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: _toggleWishlist,
                                child: Container(
                                  padding: EdgeInsets.all(2.w),
                                  child: CustomIconWidget(
                                    iconName: _isWishlisted
                                        ? 'favorite'
                                        : 'favorite_border',
                                    color: _isWishlisted
                                        ? AppTheme.primaryPink
                                        : AppTheme.primaryCyan,
                                    size: 6.w,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 4.h),

                    // Product Description
                    ProductDescriptionWidget(
                      description: productData["description"] as String,
                      features:
                          (productData["features"] as List).cast<String>(),
                      isExpanded: _isDescriptionExpanded,
                      onToggle: _toggleDescription,
                    ),

                    SizedBox(height: 4.h),

                    // Customer Reviews
                    CustomerReviewsWidget(
                      rating: productData["rating"] as double,
                      reviewCount: productData["reviewCount"] as int,
                      reviews: customerReviews,
                    ),

                    SizedBox(height: 4.h),

                    // Related Products
                    RelatedProductsWidget(
                      products: relatedProducts,
                    ),

                    SizedBox(height: 12.h), // Space for sticky bottom bar
                  ],
                ),
              ),
            ],
          ),

          // Sticky Bottom Bar
          if (_showStickyBar)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: StickyBottomBarWidget(
                currentPrice: productData["currentPrice"] as double,
                quantity: _quantity,
                isAddingToCart: _isAddingToCart,
                onAddToCart: _addToCart,
              ),
            ),
        ],
      ),
    );
  }
}
