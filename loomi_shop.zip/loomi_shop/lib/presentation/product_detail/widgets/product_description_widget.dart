import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProductDescriptionWidget extends StatelessWidget {
  final String description;
  final List<String> features;
  final bool isExpanded;
  final VoidCallback onToggle;

  const ProductDescriptionWidget({
    super.key,
    required this.description,
    required this.features,
    required this.isExpanded,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Product Details',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              GestureDetector(
                onTap: onToggle,
                child: Container(
                  padding: EdgeInsets.all(1.w),
                  decoration: BoxDecoration(
                    gradient: AppTheme.createGradientDecoration().gradient,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: CustomIconWidget(
                    iconName: isExpanded ? 'expand_less' : 'expand_more',
                    color: AppTheme.pureWhite,
                    size: 5.w,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Description
          AnimatedCrossFade(
            firstChild: Text(
              description.length > 150
                  ? '${description.substring(0, 150)}...'
                  : description,
              style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                height: 1.6,
                color: AppTheme.neutralDark,
              ),
            ),
            secondChild: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  description,
                  style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                    height: 1.6,
                    color: AppTheme.neutralDark,
                  ),
                ),
                SizedBox(height: 3.h),
                Text(
                  'Key Features',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                ...features.map((feature) => Padding(
                      padding: EdgeInsets.only(bottom: 1.h),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 0.8.h, right: 2.w),
                            width: 1.5.w,
                            height: 1.5.w,
                            decoration: BoxDecoration(
                              gradient:
                                  AppTheme.createGradientDecoration().gradient,
                              shape: BoxShape.circle,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              feature,
                              style: AppTheme.lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ),
            crossFadeState: isExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 300),
          ),

          if (!isExpanded) ...[
            SizedBox(height: 2.h),
            GestureDetector(
              onTap: onToggle,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ShaderMask(
                    shaderCallback: (bounds) =>
                        AppTheme.createGradientDecoration()
                            .gradient!
                            .createShader(bounds),
                    child: Text(
                      'Read More',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.pureWhite,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(width: 1.w),
                  ShaderMask(
                    shaderCallback: (bounds) =>
                        AppTheme.createGradientDecoration()
                            .gradient!
                            .createShader(bounds),
                    child: CustomIconWidget(
                      iconName: 'keyboard_arrow_down',
                      color: AppTheme.pureWhite,
                      size: 5.w,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
