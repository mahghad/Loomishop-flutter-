import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StickyBottomBarWidget extends StatelessWidget {
  final double currentPrice;
  final int quantity;
  final bool isAddingToCart;
  final VoidCallback onAddToCart;

  const StickyBottomBarWidget({
    super.key,
    required this.currentPrice,
    required this.quantity,
    required this.isAddingToCart,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    final totalPrice = currentPrice * quantity;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: SafeArea(
        child: Row(
          children: [
            // Price Section
            Expanded(
              flex: 2,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total Price',
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.neutralMedium,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) =>
                            AppTheme.createGradientDecoration()
                                .gradient!
                                .createShader(bounds),
                        child: Text(
                          '\$${totalPrice.toStringAsFixed(2)}',
                          style: AppTheme.lightTheme.textTheme.headlineSmall
                              ?.copyWith(
                            color: AppTheme.pureWhite,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      if (quantity > 1) ...[
                        SizedBox(width: 2.w),
                        Text(
                          '($quantity items)',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.neutralMedium,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(width: 4.w),

            // Add to Cart Button
            Expanded(
              flex: 3,
              child: Container(
                height: 7.h,
                decoration: AppTheme.createGradientDecoration(),
                child: ElevatedButton(
                  onPressed: isAddingToCart ? null : onAddToCart,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: isAddingToCart
                      ? SizedBox(
                          width: 5.w,
                          height: 5.w,
                          child: const CircularProgressIndicator(
                            color: AppTheme.pureWhite,
                            strokeWidth: 2,
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CustomIconWidget(
                              iconName: 'shopping_cart',
                              color: AppTheme.pureWhite,
                              size: 5.w,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Add to Cart',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                color: AppTheme.pureWhite,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
