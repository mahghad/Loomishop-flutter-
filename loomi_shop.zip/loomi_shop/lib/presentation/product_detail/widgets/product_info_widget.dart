import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProductInfoWidget extends StatelessWidget {
  final String name;
  final double currentPrice;
  final double originalPrice;
  final double rating;
  final int reviewCount;
  final bool inStock;
  final int stockCount;

  const ProductInfoWidget({
    super.key,
    required this.name,
    required this.currentPrice,
    required this.originalPrice,
    required this.rating,
    required this.reviewCount,
    required this.inStock,
    required this.stockCount,
  });

  Widget _buildStarRating() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        final starValue = index + 1;
        final isFullStar = rating >= starValue;
        final isHalfStar = rating >= starValue - 0.5 && rating < starValue;

        return Container(
          margin: EdgeInsets.only(right: 0.5.w),
          child: isFullStar
              ? ShaderMask(
                  shaderCallback: (bounds) =>
                      AppTheme.createGradientDecoration()
                          .gradient!
                          .createShader(bounds),
                  child: CustomIconWidget(
                    iconName: 'star',
                    color: AppTheme.pureWhite,
                    size: 4.w,
                  ),
                )
              : isHalfStar
                  ? ShaderMask(
                      shaderCallback: (bounds) =>
                          AppTheme.createGradientDecoration()
                              .gradient!
                              .createShader(bounds),
                      child: CustomIconWidget(
                        iconName: 'star_half',
                        color: AppTheme.pureWhite,
                        size: 4.w,
                      ),
                    )
                  : CustomIconWidget(
                      iconName: 'star_border',
                      color: AppTheme.neutralLight,
                      size: 4.w,
                    ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Product Name
          ShaderMask(
            shaderCallback: (bounds) => AppTheme.createGradientDecoration()
                .gradient!
                .createShader(bounds),
            child: Text(
              name,
              style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
            ),
          ),

          SizedBox(height: 2.h),

          // Price Section
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => AppTheme.createGradientDecoration()
                    .gradient!
                    .createShader(bounds),
                child: Text(
                  '\$${currentPrice.toStringAsFixed(2)}',
                  style: AppTheme.lightTheme.textTheme.headlineLarge?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Text(
                '\$${originalPrice.toStringAsFixed(2)}',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.neutralMedium,
                  decoration: TextDecoration.lineThrough,
                  decorationColor: AppTheme.neutralMedium,
                ),
              ),
              SizedBox(width: 3.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  gradient: AppTheme.createGradientDecoration().gradient,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '${(((originalPrice - currentPrice) / originalPrice) * 100).round()}% OFF',
                  style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Rating and Reviews
          Row(
            children: [
              _buildStarRating(),
              SizedBox(width: 2.w),
              Text(
                rating.toStringAsFixed(1),
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(width: 2.w),
              GestureDetector(
                onTap: () {
                  // Scroll to reviews section
                },
                child: Text(
                  '($reviewCount reviews)',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.primaryCyan,
                    decoration: TextDecoration.underline,
                    decorationColor: AppTheme.primaryCyan,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Stock Status
          Row(
            children: [
              Container(
                width: 2.w,
                height: 2.w,
                decoration: BoxDecoration(
                  color:
                      inStock ? AppTheme.successGreen : AppTheme.warningOrange,
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                inStock
                    ? stockCount > 10
                        ? 'In Stock'
                        : 'Only $stockCount left in stock'
                    : 'Out of Stock',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color:
                      inStock ? AppTheme.successGreen : AppTheme.warningOrange,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
