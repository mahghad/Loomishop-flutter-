import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RelatedProductsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> products;

  const RelatedProductsWidget({
    super.key,
    required this.products,
  });

  Widget _buildStarRating(double rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        final starValue = index + 1;
        final isFullStar = rating >= starValue;
        final isHalfStar = rating >= starValue - 0.5 && rating < starValue;

        return Container(
          margin: EdgeInsets.only(right: 0.3.w),
          child: isFullStar
              ? ShaderMask(
                  shaderCallback: (bounds) =>
                      AppTheme.createGradientDecoration()
                          .gradient!
                          .createShader(bounds),
                  child: CustomIconWidget(
                    iconName: 'star',
                    color: AppTheme.pureWhite,
                    size: 3.w,
                  ),
                )
              : isHalfStar
                  ? ShaderMask(
                      shaderCallback: (bounds) =>
                          AppTheme.createGradientDecoration()
                              .gradient!
                              .createShader(bounds),
                      child: CustomIconWidget(
                        iconName: 'star_half',
                        color: AppTheme.pureWhite,
                        size: 3.w,
                      ),
                    )
                  : CustomIconWidget(
                      iconName: 'star_border',
                      color: AppTheme.neutralLight,
                      size: 3.w,
                    ),
        );
      }),
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product, BuildContext context) {
    final id = product["id"] as int;
    final name = product["name"] as String;
    final price = product["price"] as double;
    final originalPrice = product["originalPrice"] as double;
    final rating = product["rating"] as double;
    final image = product["image"] as String;

    return GestureDetector(
      onTap: () {
        // Navigate to product detail
        Navigator.pushNamed(context, '/product-detail');
      },
      child: Container(
        width: 45.w,
        margin: EdgeInsets.only(right: 4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppTheme.shadowLight,
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Image
            Container(
              height: 25.h,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
              ),
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                child: CustomImageWidget(
                  imageUrl: image,
                  width: double.infinity,
                  height: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // Product Info
            Padding(
              padding: EdgeInsets.all(3.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),

                  SizedBox(height: 1.h),

                  // Rating
                  Row(
                    children: [
                      _buildStarRating(rating),
                      SizedBox(width: 1.w),
                      Text(
                        rating.toStringAsFixed(1),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.neutralMedium,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 1.h),

                  // Price
                  Row(
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) =>
                            AppTheme.createGradientDecoration()
                                .gradient!
                                .createShader(bounds),
                        child: Text(
                          '\$${price.toStringAsFixed(2)}',
                          style: AppTheme.lightTheme.textTheme.titleLarge
                              ?.copyWith(
                            color: AppTheme.pureWhite,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        '\$${originalPrice.toStringAsFixed(2)}',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.neutralMedium,
                          decoration: TextDecoration.lineThrough,
                          decorationColor: AppTheme.neutralMedium,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Add to Cart Button
                  SizedBox(
                    width: double.infinity,
                    height: 5.h,
                    child: Container(
                      decoration: AppTheme.createGradientDecoration(),
                      child: ElevatedButton(
                        onPressed: () {
                          // Add to cart functionality
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Add to Cart',
                          style: AppTheme.lightTheme.textTheme.titleSmall
                              ?.copyWith(
                            color: AppTheme.pureWhite,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Related Products',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/product-catalog');
                },
                child: Row(
                  children: [
                    Text(
                      'View All',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.primaryCyan,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(width: 1.w),
                    CustomIconWidget(
                      iconName: 'arrow_forward',
                      color: AppTheme.primaryCyan,
                      size: 4.w,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 2.h),
        SizedBox(
          height: 42.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            itemCount: products.length,
            itemBuilder: (context, index) {
              return _buildProductCard(products[index], context);
            },
          ),
        ),
      ],
    );
  }
}
