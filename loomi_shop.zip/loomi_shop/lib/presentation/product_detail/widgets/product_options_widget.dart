import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProductOptionsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> colors;
  final List<String> sizes;
  final int selectedColorIndex;
  final int selectedSizeIndex;
  final int quantity;
  final int maxQuantity;
  final Function(int) onColorSelected;
  final Function(int) onSizeSelected;
  final Function(int) onQuantityChanged;

  const ProductOptionsWidget({
    super.key,
    required this.colors,
    required this.sizes,
    required this.selectedColorIndex,
    required this.selectedSizeIndex,
    required this.quantity,
    required this.maxQuantity,
    required this.onColorSelected,
    required this.onSizeSelected,
    required this.onQuantityChanged,
  });

  Color _parseColor(String colorString) {
    return Color(int.parse(colorString.replaceFirst('#', '0xFF')));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Color Selection
          Text(
            'Color',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.5.h),
          SizedBox(
            height: 8.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: colors.length,
              itemBuilder: (context, index) {
                final colorData = colors[index];
                final isSelected = index == selectedColorIndex;

                return GestureDetector(
                  onTap: () => onColorSelected(index),
                  child: Container(
                    margin: EdgeInsets.only(right: 3.w),
                    child: Column(
                      children: [
                        Container(
                          width: 12.w,
                          height: 5.h,
                          decoration: BoxDecoration(
                            color: _parseColor(colorData["color"] as String),
                            borderRadius: BorderRadius.circular(8),
                            border: isSelected
                                ? Border.all(
                                    width: 3,
                                    color: AppTheme.primaryCyan,
                                  )
                                : Border.all(
                                    width: 1,
                                    color: AppTheme.neutralLight,
                                  ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: AppTheme.primaryCyan
                                          .withValues(alpha: 0.3),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          colorData["name"] as String,
                          style: AppTheme.lightTheme.textTheme.labelSmall
                              ?.copyWith(
                            color: isSelected
                                ? AppTheme.primaryCyan
                                : AppTheme.neutralMedium,
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w400,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          SizedBox(height: 3.h),

          // Size Selection
          Text(
            'Size',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.5.h),
          SizedBox(
            height: 6.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: sizes.length,
              itemBuilder: (context, index) {
                final size = sizes[index];
                final isSelected = index == selectedSizeIndex;

                return GestureDetector(
                  onTap: () => onSizeSelected(index),
                  child: Container(
                    margin: EdgeInsets.only(right: 3.w),
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? AppTheme.createGradientDecoration().gradient
                          : null,
                      color: isSelected ? null : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      border: isSelected
                          ? null
                          : Border.all(
                              color: AppTheme.neutralLight,
                              width: 1,
                            ),
                    ),
                    child: Center(
                      child: Text(
                        size,
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color: isSelected
                              ? AppTheme.pureWhite
                              : AppTheme.neutralDark,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          SizedBox(height: 3.h),

          // Quantity Selection
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Quantity',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.neutralLight),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(8),
                          bottomLeft: Radius.circular(8),
                        ),
                        onTap: quantity > 1
                            ? () => onQuantityChanged(quantity - 1)
                            : null,
                        child: SizedBox(
                          width: 10.w,
                          height: 5.h,
                          child: Center(
                            child: CustomIconWidget(
                              iconName: 'remove',
                              color: quantity > 1
                                  ? AppTheme.neutralDark
                                  : AppTheme.neutralLight,
                              size: 5.w,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: 15.w,
                      height: 5.h,
                      decoration: BoxDecoration(
                        border: Border.symmetric(
                          vertical: BorderSide(color: AppTheme.neutralLight),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          quantity.toString(),
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(8),
                          bottomRight: Radius.circular(8),
                        ),
                        onTap: quantity < maxQuantity
                            ? () => onQuantityChanged(quantity + 1)
                            : null,
                        child: SizedBox(
                          width: 10.w,
                          height: 5.h,
                          child: Center(
                            child: CustomIconWidget(
                              iconName: 'add',
                              color: quantity < maxQuantity
                                  ? AppTheme.neutralDark
                                  : AppTheme.neutralLight,
                              size: 5.w,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
