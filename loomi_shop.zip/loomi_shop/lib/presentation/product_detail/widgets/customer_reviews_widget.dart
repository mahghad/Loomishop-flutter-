import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CustomerReviewsWidget extends StatefulWidget {
  final double rating;
  final int reviewCount;
  final List<Map<String, dynamic>> reviews;

  const CustomerReviewsWidget({
    super.key,
    required this.rating,
    required this.reviewCount,
    required this.reviews,
  });

  @override
  State<CustomerReviewsWidget> createState() => _CustomerReviewsWidgetState();
}

class _CustomerReviewsWidgetState extends State<CustomerReviewsWidget> {
  bool _showAllReviews = false;

  Widget _buildStarRating(double rating, {double size = 4}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        final starValue = index + 1;
        final isFullStar = rating >= starValue;
        final isHalfStar = rating >= starValue - 0.5 && rating < starValue;

        return Container(
          margin: EdgeInsets.only(right: 0.5.w),
          child: isFullStar
              ? ShaderMask(
                  shaderCallback: (bounds) =>
                      AppTheme.createGradientDecoration()
                          .gradient!
                          .createShader(bounds),
                  child: CustomIconWidget(
                    iconName: 'star',
                    color: AppTheme.pureWhite,
                    size: size.w,
                  ),
                )
              : isHalfStar
                  ? ShaderMask(
                      shaderCallback: (bounds) =>
                          AppTheme.createGradientDecoration()
                              .gradient!
                              .createShader(bounds),
                      child: CustomIconWidget(
                        iconName: 'star_half',
                        color: AppTheme.pureWhite,
                        size: size.w,
                      ),
                    )
                  : CustomIconWidget(
                      iconName: 'star_border',
                      color: AppTheme.neutralLight,
                      size: size.w,
                    ),
        );
      }),
    );
  }

  Widget _buildRatingDistribution() {
    // Mock rating distribution data
    final ratingDistribution = [
      {"stars": 5, "count": 623, "percentage": 0.5},
      {"stars": 4, "count": 374, "percentage": 0.3},
      {"stars": 3, "count": 125, "percentage": 0.1},
      {"stars": 2, "count": 75, "percentage": 0.06},
      {"stars": 1, "count": 50, "percentage": 0.04},
    ];

    return Column(
      children: ratingDistribution.map((data) {
        final stars = data["stars"] as int;
        final count = data["count"] as int;
        final percentage = data["percentage"] as double;

        return Padding(
          padding: EdgeInsets.only(bottom: 1.h),
          child: Row(
            children: [
              Text(
                '$stars',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(width: 1.w),
              CustomIconWidget(
                iconName: 'star',
                color: AppTheme.neutralMedium,
                size: 3.w,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Container(
                  height: 1.h,
                  decoration: BoxDecoration(
                    color: AppTheme.neutralLight,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: percentage,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: AppTheme.createGradientDecoration().gradient,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                count.toString(),
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.neutralMedium,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildReviewCard(Map<String, dynamic> review) {
    final userName = review["userName"] as String;
    final rating = review["rating"] as int;
    final date = review["date"] as String;
    final reviewText = review["review"] as String;
    final helpful = review["helpful"] as int;
    final verified = review["verified"] as bool;

    return Container(
      margin: EdgeInsets.only(bottom: 3.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.neutralLight.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 10.w,
                height: 10.w,
                decoration: BoxDecoration(
                  gradient: AppTheme.createGradientDecoration().gradient,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    userName.substring(0, 1).toUpperCase(),
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.pureWhite,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          userName,
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (verified) ...[
                          SizedBox(width: 1.w),
                          CustomIconWidget(
                            iconName: 'verified',
                            color: AppTheme.successGreen,
                            size: 4.w,
                          ),
                        ],
                      ],
                    ),
                    SizedBox(height: 0.5.h),
                    Row(
                      children: [
                        _buildStarRating(rating.toDouble(), size: 3),
                        SizedBox(width: 2.w),
                        Text(
                          date,
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.neutralMedium,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Text(
            reviewText,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              height: 1.5,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Text(
                'Helpful?',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.neutralMedium,
                ),
              ),
              SizedBox(width: 2.w),
              GestureDetector(
                onTap: () {
                  // Handle helpful vote
                },
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'thumb_up',
                      color: AppTheme.primaryCyan,
                      size: 4.w,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      helpful.toString(),
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.primaryCyan,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayedReviews =
        _showAllReviews ? widget.reviews : widget.reviews.take(2).toList();

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section Header
          Text(
            'Customer Reviews',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),

          SizedBox(height: 3.h),

          // Rating Overview
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) =>
                              AppTheme.createGradientDecoration()
                                  .gradient!
                                  .createShader(bounds),
                          child: Text(
                            widget.rating.toStringAsFixed(1),
                            style: AppTheme.lightTheme.textTheme.displaySmall
                                ?.copyWith(
                              color: AppTheme.pureWhite,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'out of 5',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.neutralMedium,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 1.h),
                    _buildStarRating(widget.rating),
                    SizedBox(height: 1.h),
                    Text(
                      '${widget.reviewCount} reviews',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.neutralMedium,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                flex: 3,
                child: _buildRatingDistribution(),
              ),
            ],
          ),

          SizedBox(height: 4.h),

          // Reviews List
          ...displayedReviews.map((review) => _buildReviewCard(review)),

          // Show More/Less Button
          if (widget.reviews.length > 2)
            Center(
              child: TextButton(
                onPressed: () {
                  setState(() {
                    _showAllReviews = !_showAllReviews;
                  });
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) =>
                          AppTheme.createGradientDecoration()
                              .gradient!
                              .createShader(bounds),
                      child: Text(
                        _showAllReviews ? 'Show Less' : 'Show All Reviews',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color: AppTheme.pureWhite,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(width: 1.w),
                    ShaderMask(
                      shaderCallback: (bounds) =>
                          AppTheme.createGradientDecoration()
                              .gradient!
                              .createShader(bounds),
                      child: CustomIconWidget(
                        iconName: _showAllReviews
                            ? 'keyboard_arrow_up'
                            : 'keyboard_arrow_down',
                        color: AppTheme.pureWhite,
                        size: 5.w,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
