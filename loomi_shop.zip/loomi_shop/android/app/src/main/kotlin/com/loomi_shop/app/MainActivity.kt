package com.loomi_shop.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
